﻿//B1646
//Program 2
//October 19 2017
//CIS 199-75
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class Spring_2018Regristration : Form
    {
        public Spring_2018Regristration()
        {
            InitializeComponent();
        }

        private void Calcbutton_Click(object sender, EventArgs e)
        {
            const string SENIORS = "FRIDAY, NOV. 3"; //seniors regristration day
            const string JUNIORS = "MONDAY, NOV. 6"; //juniors regristration day
            const string SOPHMORES_DAY1 = "TUESDAY, NOV. 7"; //sophmores regristration day 1
            const string SOPHMORES_DAY2 = "WEDNESDAY, NOV. 8"; //sophmores regristration day 2
            const string FRESHMAN_DAY1 = "THURSDAY, NOV. 9"; //freshman regristration day 1
            const string FRESHMAN_DAY2 = "FRIDAY, NOV. 10"; //freshman regristration day 2 

            string lastName = lastnameInputtextBox.Text; //users last name for input 
            char firstLetter; // first letter of last name


            if (char.TryParse(lastnameInputtextBox.Text, out firstLetter)) //grabs first letter only
            {
                firstLetter = char.ToUpper(firstLetter); //changes user input to an uppercase letter
                firstLetter = lastName[0]; //0 enters the first letter of the last name
                if (FreshmanradioButton.Checked) //radio button for freshmans 
                {
                    if (firstLetter >= 'G' && firstLetter <= 'S') //range of letters for freshmans regristration day 2 
                    {
                        Outputlabel.Text = FRESHMAN_DAY2; //regristration day 2 with else if statements that conatins the range of letters and specific times
                        if (firstLetter <= 'I')
                        {
                            Outputlabel.Text = (Outputlabel.Text + " at 8:30am");
                        }
                        else if (firstLetter <= 'L')
                        {
                            Outputlabel.Text = (Outputlabel.Text + " at 10:00am");
                        }
                        else if (firstLetter <= 'O')
                        {
                            Outputlabel.Text = (Outputlabel.Text + " at 11:30am");
                        }
                        else if (firstLetter <= 'Q')
                        {
                            Outputlabel.Text = (Outputlabel.Text + " at 2:00pm");
                        }
                        else if (firstLetter <= 'S')
                        {
                            Outputlabel.Text = (Outputlabel.Text + " at 4:00pm");
                        }
                    }
                    else
                    {
                        Outputlabel.Text = FRESHMAN_DAY1; //regristration day 1 with else if statements below with the letter and specific times 
                        if (firstLetter <= 'B')
                        {
                            Outputlabel.Text = (Outputlabel.Text + " at 11:30am "); //shows output in output label  
                        }
                        else if (firstLetter <= 'D')
                        {
                            Outputlabel.Text = (Outputlabel.Text + " at 2:00pm"); //shows output in output label 
                        }
                        else if (firstLetter <= 'F')
                        {
                            Outputlabel.Text = (Outputlabel.Text + " at 4:00am"); //shows output in output label 
                        }
                        else if (firstLetter <= 'V')
                        {
                            Outputlabel.Text = (Outputlabel.Text + " at 8:30am"); //shows output in output label  
                        }
                        else if (firstLetter <= 'Z')
                        {
                            Outputlabel.Text = (Outputlabel.Text + " at 10:00am"); //shows output in output label 
                        }
                        else
                        {
                            MessageBox.Show("Please enter last name"); //when user input is invalid
                        }
                    }
                }
                if (SophmoreradioButton.Checked) //radio button for sophmores 
                {
                    if (firstLetter >= 'G' && firstLetter <= 'S') //range of first letters of last name for regristration day 2 for sophmores 
                        Outputlabel.Text = SOPHMORES_DAY2; //regristration day 2 with else if statements below with specific first letter of last name and time
                    if (firstLetter <= 'I')
                    {
                        Outputlabel.Text = (Outputlabel.Text + " at 8:30am"); //shows output in output label 
                    }
                    else if (firstLetter <= 'L')
                    {
                        Outputlabel.Text = (Outputlabel.Text + " at 10:00am"); //shows output in output label 
                    }
                    else if (firstLetter <= 'O')
                    {
                        Outputlabel.Text = (Outputlabel.Text + " at 11:30am"); //shows output in output label 
                    }
                    else if (firstLetter <= 'Q')
                    {
                        Outputlabel.Text = (Outputlabel.Text + " at 2:00pm"); //shows output in output label
                    }
                    else if (firstLetter <= 'S')
                    {
                        Outputlabel.Text = (Outputlabel.Text + " at 4:00pm"); //shows output in output label
                    }
                    else
                    {
                        Outputlabel.Text = SOPHMORES_DAY1; //regristration day 1 for sophmores with else if statement for specific first letter and time  
                    }
                    if (firstLetter <= 'B')
                    {
                        Outputlabel.Text = (Outputlabel.Text + " at 11:30am "); //shows output in output label  
                    }
                    else if (firstLetter <= 'D')
                    {
                        Outputlabel.Text = (Outputlabel.Text + " at 2:00pm"); //shows output in output label 
                    }
                    else if (firstLetter <= 'F')
                    {
                        Outputlabel.Text = (Outputlabel.Text + " at 4:00am"); //shows output in output label 
                    }
                    else if (firstLetter <= 'V')
                    {
                        Outputlabel.Text = (Outputlabel.Text + " at 8:30am"); //shows output in output label  
                    }
                    else if (firstLetter <= 'Z')
                    {
                        Outputlabel.Text = (Outputlabel.Text + " at 10:00am"); //shows output in output label 
                    }
                    else
                    {
                        MessageBox.Show("Please enter last name"); //invalid user input
                    }
                }
                if (JuniorradioButton.Checked) //radio button for juniors 
                {
                    if (firstLetter <= 'Z' && firstLetter >= 'A') //range of first letters for juniors for regristration day 
                        Outputlabel.Text = JUNIORS; //juniors regristration day with else if statements with specific first letter and time 
                    if (firstLetter <= 'D')
                    {
                        Outputlabel.Text = (Outputlabel.Text + " at 10:00am");//shows output in output label
                    }
                    else if (firstLetter <= 'I')
                    {
                        Outputlabel.Text = (Outputlabel.Text + " at 11:30am");//shows output in output label
                    }
                    else if (firstLetter <= 'O')
                    {
                        Outputlabel.Text = (Outputlabel.Text + " at 2:00pm");//shows output in output label
                    }
                    else if (firstLetter <= 'S')
                    {
                        Outputlabel.Text = (Outputlabel.Text + " at 4:00pm");//shows output in output label
                    }
                    else if (firstLetter <= 'Z')
                    {
                        Outputlabel.Text = (Outputlabel.Text + " at 8:30am");//shows output in output label
                    }
                    else
                    {
                        MessageBox.Show("Please enter last name"); //ivalid user input
                    }
                }
                                if (SeniorradioButton.Checked) //radio button for seniors
                                {
                                    if (firstLetter <= 'Z' && firstLetter >= 'A') //range of first letters of last name 
                                        Outputlabel.Text = SENIORS; //holds regristration day for seniors followed by else if statements with specific day and time 
                                    if (firstLetter <= 'D')
                                    {
                                        Outputlabel.Text = (Outputlabel.Text + " at 10:00am");//shows output in output label
                    }
                                    else if (firstLetter <= 'I')
                                    {
                                        Outputlabel.Text = (Outputlabel.Text + " at 11:30am");//shows output in output label
                    }
                                    else if (firstLetter <= 'O')
                                    {
                                        Outputlabel.Text = (Outputlabel + " at 2:00pm");//shows output in output label
                    }
                                    else if (firstLetter <= 'S')
                                    {
                                        Outputlabel.Text = (Outputlabel.Text + " at 4:00pm");//shows output in output label
                    }
                                    else if (firstLetter <= 'Z')
                                    {
                                        Outputlabel.Text = (Outputlabel.Text + " at 8:30am");//shows output in output label
                    }
                                    else
                                    {
                                        MessageBox.Show("Please enter last name"); //invalid user input
                                    }

                                }

                            }




                        }
                    }

                }
            

        

    



