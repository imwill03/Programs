﻿namespace Program_2
{
    partial class Spring_2018Regristration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LastnameLabel = new System.Windows.Forms.Label();
            this.lastnameInputtextBox = new System.Windows.Forms.TextBox();
            this.FreshmanradioButton = new System.Windows.Forms.RadioButton();
            this.SophmoreradioButton = new System.Windows.Forms.RadioButton();
            this.JuniorradioButton = new System.Windows.Forms.RadioButton();
            this.SeniorradioButton = new System.Windows.Forms.RadioButton();
            this.Calcbutton = new System.Windows.Forms.Button();
            this.Outputlabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LastnameLabel
            // 
            this.LastnameLabel.AutoSize = true;
            this.LastnameLabel.Location = new System.Drawing.Point(30, 33);
            this.LastnameLabel.Name = "LastnameLabel";
            this.LastnameLabel.Size = new System.Drawing.Size(92, 13);
            this.LastnameLabel.TabIndex = 0;
            this.LastnameLabel.Text = "Enter Last Name: ";
            // 
            // lastnameInputtextBox
            // 
            this.lastnameInputtextBox.Location = new System.Drawing.Point(150, 30);
            this.lastnameInputtextBox.Name = "lastnameInputtextBox";
            this.lastnameInputtextBox.Size = new System.Drawing.Size(100, 20);
            this.lastnameInputtextBox.TabIndex = 1;
            // 
            // FreshmanradioButton
            // 
            this.FreshmanradioButton.AutoSize = true;
            this.FreshmanradioButton.Location = new System.Drawing.Point(100, 88);
            this.FreshmanradioButton.Name = "FreshmanradioButton";
            this.FreshmanradioButton.Size = new System.Drawing.Size(71, 17);
            this.FreshmanradioButton.TabIndex = 6;
            this.FreshmanradioButton.TabStop = true;
            this.FreshmanradioButton.Text = "Freshman";
            this.FreshmanradioButton.UseVisualStyleBackColor = true;
            // 
            // SophmoreradioButton
            // 
            this.SophmoreradioButton.AutoSize = true;
            this.SophmoreradioButton.Location = new System.Drawing.Point(100, 126);
            this.SophmoreradioButton.Name = "SophmoreradioButton";
            this.SophmoreradioButton.Size = new System.Drawing.Size(73, 17);
            this.SophmoreradioButton.TabIndex = 7;
            this.SophmoreradioButton.TabStop = true;
            this.SophmoreradioButton.Text = "Sophmore";
            this.SophmoreradioButton.UseVisualStyleBackColor = true;
            // 
            // JuniorradioButton
            // 
            this.JuniorradioButton.AutoSize = true;
            this.JuniorradioButton.Location = new System.Drawing.Point(100, 162);
            this.JuniorradioButton.Name = "JuniorradioButton";
            this.JuniorradioButton.Size = new System.Drawing.Size(53, 17);
            this.JuniorradioButton.TabIndex = 8;
            this.JuniorradioButton.TabStop = true;
            this.JuniorradioButton.Text = "Junior";
            this.JuniorradioButton.UseVisualStyleBackColor = true;
            // 
            // SeniorradioButton
            // 
            this.SeniorradioButton.AutoSize = true;
            this.SeniorradioButton.Location = new System.Drawing.Point(100, 196);
            this.SeniorradioButton.Name = "SeniorradioButton";
            this.SeniorradioButton.Size = new System.Drawing.Size(55, 17);
            this.SeniorradioButton.TabIndex = 9;
            this.SeniorradioButton.TabStop = true;
            this.SeniorradioButton.Text = "Senior";
            this.SeniorradioButton.UseVisualStyleBackColor = true;
            // 
            // Calcbutton
            // 
            this.Calcbutton.Location = new System.Drawing.Point(28, 228);
            this.Calcbutton.Name = "Calcbutton";
            this.Calcbutton.Size = new System.Drawing.Size(94, 33);
            this.Calcbutton.TabIndex = 10;
            this.Calcbutton.Text = "Enter";
            this.Calcbutton.UseVisualStyleBackColor = true;
            this.Calcbutton.Click += new System.EventHandler(this.Calcbutton_Click);
            // 
            // Outputlabel
            // 
            this.Outputlabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Outputlabel.Location = new System.Drawing.Point(165, 228);
            this.Outputlabel.Name = "Outputlabel";
            this.Outputlabel.Size = new System.Drawing.Size(115, 33);
            this.Outputlabel.TabIndex = 11;
            // 
            // Spring_2018Regristration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.Outputlabel);
            this.Controls.Add(this.Calcbutton);
            this.Controls.Add(this.SeniorradioButton);
            this.Controls.Add(this.JuniorradioButton);
            this.Controls.Add(this.SophmoreradioButton);
            this.Controls.Add(this.FreshmanradioButton);
            this.Controls.Add(this.lastnameInputtextBox);
            this.Controls.Add(this.LastnameLabel);
            this.Name = "Spring_2018Regristration";
            this.Text = "Spring 2018 Regristration ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LastnameLabel;
        private System.Windows.Forms.TextBox lastnameInputtextBox;
        private System.Windows.Forms.RadioButton FreshmanradioButton;
        private System.Windows.Forms.RadioButton SophmoreradioButton;
        private System.Windows.Forms.RadioButton JuniorradioButton;
        private System.Windows.Forms.RadioButton SeniorradioButton;
        private System.Windows.Forms.Button Calcbutton;
        private System.Windows.Forms.Label Outputlabel;
    }
}

