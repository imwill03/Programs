﻿//B1646
//Program 1
//September 26 2017
//CIS 199-78
//Calculating the amount of paint needed
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program__1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Handy-Dandy Paint Estimator");
            //declaring variables
            const int PER_CAN = 350; //named constant for the literal 350
            Console.Write("Enter the total of all walls(in feet):");
            double totalLength = Convert.ToDouble (Console.ReadLine()); //variable for the total length
            Console.Write("Enter the height of the walls (in feet):");
            double height = Convert.ToDouble(Console.ReadLine()); //variable for the height
            Console.Write("Enter the number of doors (non-neg int):");
            int numberDoors = Convert.ToInt32(Console.ReadLine()); //variable for the number of doors
            Console.Write("Enter the number of windows (non-neg int):");
            int numberWindows = Convert.ToInt32(Console.ReadLine()); //variable for the number of windows
            Console.Write("Enter the number of coats of paint (non-neg int):");
            int numberCoats = Convert.ToInt32(Console.ReadLine()); //variable for the number of coats

            //calculations
            double totalSqt = (totalLength * height) - (numberDoors + numberWindows); //calcs the total sqt
            double newTotalSqt = totalSqt * numberCoats; //calcs the new total sqt
            double minGallons = newTotalSqt / PER_CAN; //calcs the min gallons
            int gallonsToBuy = (int)Math.Ceiling(minGallons); //calcs gallon to buy

            Console.WriteLine($"You need the minimun of {minGallons} gallons of paint");
            Console.WriteLine($"You'll need to buy {gallonsToBuy} gallons, though");












        }
    
    }
}
