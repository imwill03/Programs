﻿//B1646
//Program 4
//12-5-2017
//CIS 199-75
//Program prints out a list of books with the constructor and calls if book is checked out or returned to shelf using boolean variables. 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    public class LibraryBook
    {
        string _Title; //title variable declared 
        string _Author; //author variable declared
        string _Publisher; //publisher variable declared
        int _CopyrightYear; //conpyright year variable declared
        string _CallNumber; //call number variable declared
        public LibraryBook(string title, string author, string publisher, int copyrightYear, string callNumber) //precondition: none. postcondition: 5 object constructor: title, author, publisher, copyright year and call number
        {
            Title = title; //set the title
            Author = author; //set the author
            Publisher = publisher; //set the publisher
            CopyrightYear = copyrightYear; //set the copyright year
            CallNumber = callNumber; //set the call number
           
        }
        private bool checkedoutstatus = false; //precondition: none. postcondition: return bool varibale false 
        public string Title //precondition: none. postcondition: returns title 
        {
            get
            {
                return _Title;

            }
            set
            {
                _Title = value;
            }
        }
        public string Author //precondition: none. postcondition: returns author
        {
            get
            {
                return _Author;
            }
            set
            {
                _Author = value;
            }
        }
        public string Publisher //precondition: none. postcondition: returns publisher
        {
            get
            {
                return _Publisher;
           
            }
            set
            {
                _Publisher = value;
            }
        }
        public int CopyrightYear //precondition: value >= 0. postcondition: returns a set value if conditions arent met. 
        {
            get
            {
                return _CopyrightYear;
            }
            set
            {
                if (value >= 0) //value has to be greater than or equal to 0. 
                    _CopyrightYear = value;
                else
                    _CopyrightYear = 2017; //set value if conditions arent met 
            }
        }
        public string CallNumber //precondition: none. postcondition: returns call number
        {
            get
            {
                return _CallNumber;
            }
            set
            {
                _CallNumber = value;
            }
        }
        public void CheckOut() //precondition: none. postcondtion: returns true 
        {
            checkedoutstatus = true; //book is checked out 
        }
        public void ReturnToShelf() //precondition: none. postcondition: returns a checked out status of false meaning the book is on shelf
        {
            checkedoutstatus = false; //book is on shelf
        }
        public bool IsCheckedOut() //precondition: none. postcondition: returns checkedout status if true 
        {
            if(checkedoutstatus == true) //book is checked out 
            {
                return checkedoutstatus;
            }
            else
            {
                return false; //book is on shelf
            }
        }
        public override string ToString() //precondition: none. postcondition: a line of text string
        {
            string text = "Title: " + Title + Environment.NewLine + "Author: " + Author + Environment.NewLine + "Publisher: " + Publisher + Environment.NewLine + "Copyright Year: " + CopyrightYear + Environment.NewLine + "Call Number: " + CallNumber + Environment.NewLine + "Checked Out Status: " + checkedoutstatus;
            return text; 
        }
    }

}
