﻿//B1646
//Program 4
//12-5-2017
//CIS 199-75
//Program prints out a list of books with the constructor and calls if book is checked out or returned to shelf using boolean variables.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Books array class objects
            //precondition none. postcondition: book array with five objects. 
            LibraryBook book1 = new LibraryBook("Rainbow Fish", "Marcus Pfister", "North-Side Books", 1996, "C12345");
            LibraryBook book2 = new LibraryBook("The Very Hungry Caterpillar", "National Geographic Learning", "Philomel", 1996, "C6789");
            LibraryBook book3 = new LibraryBook("Love You forever", "Munsch", "Firefly Books Ltd", 1986, "C62693");
            LibraryBook book4 = new LibraryBook("Goodnight Moon", "Brown", "Harpercollins Children Books", 1993, "C07632");
            LibraryBook book5 = new LibraryBook("pat the Bunny", "Dorthy Kunhardt", "Golden Books Pub Co Inc", 1988, "C95126");

            LibraryBook[] books = new LibraryBook[5];//postcondition: none. precondition: array of 5 books

            books[0] = book1; //sets book1
            books[1] = book2; //sets book2
            books[2] = book3; //sets book3 
            books[3] = book4; //sets book4
            books[4] = book5; //sets book5

            ShowBook(books);//Prints out data //precondition: none postcondition: prints out data 
            
            books[0].Publisher = "The blue bird"; //changed publisher 
            books[1].Publisher = "Sunflower"; //changed publisher
            books[2].Publisher = "Pink Stars"; //changed publisher 
            books[3].CheckOut(); //book is checked out 
            books[4].CheckOut(); //book is checked out 

            ShowBook(books);//prints out new data //precondition: none. postcondition: prints out new data

            books[3].ReturnToShelf(); //book is on shelf
            books[4].ReturnToShelf(); //book is on shelf

            ShowBook(books);//prints out new data //precondition: none. postcondition: prints out data again 






        }
        public static void ShowBook(LibraryBook[]bookarray) //precondition: none postcondition: shows the objects and output 
        {
            foreach (LibraryBook book in bookarray) //precondition: none. postcondition: loops through the elements in the array
                Console.WriteLine(book.ToString()); //precondition: none. postcondition: shows the list of books
        }
            
    }
}
